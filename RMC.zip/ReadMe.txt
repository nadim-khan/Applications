OPEN VScode --- its a node js app
run nodemon app.js
open browser
localhost:3000/contact